Be sure to [search for your issue](https://github.com/CookPete/react-player/issues) before opening a new one.

#### Current Behavior
<!-- Describe what is happening -->

#### Expected Behavior
<!-- Describe what you are expecting to happen -->

#### Steps to Reproduce
<!-- Provide as much detail as possible -->
1.
1.
1.

#### Environment
- URL attempting to play: 
- Browser: 
- Operating system: 
- jsFiddle example: https://jsfiddle.net/sv5x3ug1

#### Other Information
<!-- Anything else to add -->
