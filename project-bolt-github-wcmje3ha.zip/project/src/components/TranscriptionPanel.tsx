import React from 'react';
import { Box, Typography, Paper } from '@mui/material';

interface TranscriptionPanelProps {
  originalText: string;
  translatedText: string;
}

const TranscriptionPanel: React.FC<TranscriptionPanelProps> = ({ originalText, translatedText }) => {
  return (
    <Paper elevation={3} sx={{ p: 2, mb: 2 }}>
      <Box>
        <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
          Original Text:
        </Typography>
        <Typography variant="body1" sx={{ mb: 2 }}>
          {originalText || 'No transcription yet'}
        </Typography>
      </Box>
      <Box>
        <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
          Translation:
        </Typography>
        <Typography variant="body1">
          {translatedText || 'No translation yet'}
        </Typography>
      </Box>
    </Paper>
  );
};

export default TranscriptionPanel;