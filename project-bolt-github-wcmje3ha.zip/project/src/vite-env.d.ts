/// <reference types="vite/client" />

interface Window {
  webkitSpeechRecognition: any;
}